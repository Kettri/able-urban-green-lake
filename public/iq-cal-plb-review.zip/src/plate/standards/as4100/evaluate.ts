import { columnCapacity } from "./member.ts"
import { alphaD, alphaFFlange, alphaVStiffened, alphaVUnstiffened, shearYield, stockyLimit } from "./shear.ts"
import {
  AS4100_META, blankCheck, blocks, designDefaults, fmt, kn, phiOf, pos, utilisation,
  type Check, type DesignInput,
} from "./shared.ts"
import { kbo, lambdaE, lambdaEy624, limits52, residualLabel } from "./tables.ts"

export type Diagram = {
  edges: "one" | "both" | null
  stress: string
  clearMm: number | null
  effectiveMm: number | null
  thicknessMm: number | null
}

export type Report = {
  meta: typeof AS4100_META
  checks: Check[]
  diagram: Diagram
  limitations: string[]
  governing: string
  governingUtil: number | null
  overall: "pass" | "not-complete"
  headline: string
}

function outsideMaterial(fy: number | null, thickness: number | null): string | null {
  if (thickness != null && thickness > 0 && thickness < 3) {
    return "Clause 1.1.2(a): AS 4100 does not apply to a steel element less than 3 mm thick, other than the cold-formed hollow-section exception, which this plate is not."
  }
  if (fy != null && fy > 690) {
    return "Clause 1.1.2(b): the yield stress used in design exceeds 690 MPa."
  }
  return null
}

function scopeRow(id: string, group: string, title: string, clause: string, note: string): Check {
  return blankCheck({
    id, group, title, clause, equation: "Clause 1.1.2",
    status: "out-of-scope", result: "OUTSIDE IMPLEMENTED SCOPE", note,
  })
}

const SIZE_KEYS = [
  "clearWidthMm", "thicknessMm", "fyMpa", "fuMpa", "kb", "anMm2", "kt",
  "dpMm", "twMm", "d1Mm", "sMm", "bfoMm", "tfMm",
  "afgMm2", "afnMm2", "afeMm2", "dfMm", "flangeFyMpa", "flangeFuMpa",
  "bbfMm", "bbMm", "bsMm", "bearingTfMm", "asMm2", "fysMpa", "tsMm", "besMm", "isMm4",
  "torsionDepthMm", "torsionTfMm", "fMemberN", "d2Mm", "asLongMm2", "isLongMm4",
  "lwMm", "modulusMpa", "endGapMm", "aepMm2", "nwN", "rwN", "vwN", "fnN", "fpN",
] as const

const SIGNED_KEYS = ["nStarN", "mStarNmm", "mwNmm", "mpNmm", "eccMm"] as const

function invalidInput(input: DesignInput): string | null {
  for (const key of SIZE_KEYS) {
    const value = input[key]
    if (value == null) continue
    if (!Number.isFinite(value)) return `${key} is not a finite number.`
    if (value < 0) return `${key} is negative.`
    if (value === 0 && (key.endsWith("Mm") || key.endsWith("Mpa") || key === "kt" || key === "kb")) {
      return `${key} is zero.`
    }
  }
  for (const key of SIGNED_KEYS) {
    const value = input[key]
    if (value == null) continue
    if (!Number.isFinite(value)) return `${key} is not a finite number.`
  }
  if (input.vStarN != null && !Number.isFinite(input.vStarN)) return "vStarN is not a finite number."
  if (input.vStarN != null && input.vStarN < 0) return "vStarN is negative. Shear is not entered as a signed tension."
  if (input.rStarN != null && !Number.isFinite(input.rStarN)) return "rStarN is not a finite number."
  if (input.rStarN != null && input.rStarN < 0) return "rStarN is negative."
  if (input.weldKnPerMm != null && (!Number.isFinite(input.weldKnPerMm) || input.weldKnPerMm < 0)) {
    return "weldKnPerMm is not a finite non-negative weld capacity."
  }
  return null
}

function data(partial: Omit<Parameters<typeof blankCheck>[0], "status" | "result" | "note"> & { missing: string; note?: string }): Check {
  const { missing, note, ...rest } = partial
  return blankCheck({
    ...rest,
    status: "data-required",
    result: "VERIFIED STANDARD DATA REQUIRED",
    note: note || missing,
    steps: [...(rest.steps ?? []), missing],
  })
}

function slenderness(input: DesignInput): { checks: Check[]; be: number | null; lambda: number | null } {
  const checks: Check[] = []
  const want = input.role === "element" || (input.role === "web" && (input.stress != null || input.axial === "compression"))
  if (input.role == null) {
    checks.push(blankCheck({
      id: "slenderness", group: "PLATE SLENDERNESS", title: "Element slenderness",
      clause: "5.2.2 / 6.2.3", equation: "λe = (b/t) √(fy/250)",
      result: "NOT CHECKED", status: "not-checked", kind: "classification",
      note: "Plate role is not selected, so b is not taken from the panel model.",
    }))
    return { checks, be: null, lambda: null }
  }
  if (!want) {
    checks.push(blankCheck({
      id: "slenderness", group: "PLATE SLENDERNESS", title: "Element slenderness",
      clause: "5.2.2", equation: "λe = (b/t) √(fy/250)",
      result: "NOT APPLICABLE", status: "not-applicable", kind: "classification",
      note: "No compression stress condition and no axial compression. Clause 5.11 shear does not use λe.",
    }))
    return { checks, be: null, lambda: null }
  }
  if (!pos(input.clearWidthMm) || !pos(input.thicknessMm) || !pos(input.fyMpa) || !input.edgesSupported || !input.stress) {
    checks.push(data({
      id: "slenderness", group: "PLATE SLENDERNESS", title: "Element slenderness",
      clause: "5.2.2 / 6.2.3", equation: "λe = (b/t) √(fy/250)",
      missing: "Required: clear width b (not the panel a or b until you assign it), thickness t, fy, longitudinal edges supported (one or both), and the stress condition.",
    }))
    return { checks, be: null, lambda: null }
  }
  if (input.thicknessMm < 3) {
    checks.push(blankCheck({
      id: "slenderness", group: "PLATE SLENDERNESS", title: "Element slenderness",
      clause: "1.1.2(a)", equation: "λe = (b/t) √(fy/250)",
      result: "OUTSIDE IMPLEMENTED SCOPE", status: "out-of-scope",
      note: "AS 4100 does not apply to steel elements less than 3 mm thick, other than the cold-formed hollow-section exception, which this plate is not.",
    }))
    return { checks, be: null, lambda: null }
  }
  if (input.fyMpa > 690) {
    checks.push(blankCheck({
      id: "slenderness", group: "PLATE SLENDERNESS", title: "Element slenderness",
      clause: "1.1.2(b)", equation: "λe = (b/t) √(fy/250)",
      result: "OUTSIDE IMPLEMENTED SCOPE", status: "out-of-scope",
      note: "The yield stress used in design exceeds 690 MPa, which Clause 1.1.2(b) excludes.",
    }))
    return { checks, be: null, lambda: null }
  }
  const needsResidual = !(input.edgesSupported === "both" && input.stress === "edge-gradient")
  if (needsResidual && !input.residual) {
    checks.push(data({
      id: "slenderness", group: "PLATE SLENDERNESS", title: "Element slenderness",
      clause: "5.2.2", equation: "λe = (b/t) √(fy/250)",
      missing: "Residual-stress category is required (SR, HR, LW, CF or HW). It is not assumed. Table 5.2 note: welded members with compressive residual stress below 40 MPa may be entered as lightly welded.",
    }))
    return { checks, be: null, lambda: null }
  }
  if (input.edgesSupported === "one" && input.stress === "edge-gradient") {
    checks.push(blankCheck({
      id: "slenderness", group: "PLATE SLENDERNESS", title: "Element slenderness",
      clause: "Table 5.2", equation: "λe = (b/t) √(fy/250)",
      result: "NOT APPLICABLE", status: "not-applicable", kind: "classification",
      note: "Table 5.2 has no row for one supported edge with compression at one edge and tension at the other. Use the outstand gradient row only when the maximum compression is at the unsupported edge.",
    }))
    return { checks, be: null, lambda: null }
  }
  const limits = limits52(input.edgesSupported, input.stress, input.residual)
  if (!limits) {
    checks.push(data({
      id: "slenderness", group: "PLATE SLENDERNESS", title: "Element slenderness",
      clause: "Table 5.2", equation: "λe = (b/t) √(fy/250)",
      missing: "No Table 5.2 row matches this edge support and stress condition.",
    }))
    return { checks, be: null, lambda: null }
  }
  const b = input.clearWidthMm
  const t = input.thicknessMm
  const fy = input.fyMpa
  const le = lambdaE(b, t, fy)
  const cls = le <= limits.ep ? "COMPACT" : le <= limits.ey ? "NON-COMPACT" : "SLENDER"
  const bWords = input.edgesSupported === "one"
    ? "clear width of the outstand from the face of the supporting plate"
    : "clear width between the faces of the supporting plates"
  checks.push(blankCheck({
    id: "slenderness", group: "PLATE SLENDERNESS", title: "Element slenderness and classification",
    clause: "5.2.2", equation: "λe = (b/t) √(fy/250); compare λe with λep and λey",
    kind: "classification",
    status: "pass",
    result: `${cls}; λe = ${fmt(le, 3)}`,
    steps: [
      `Selected element: flat plate, ${input.edgesSupported === "one" ? "one longitudinal edge supported" : "both longitudinal edges supported"}.`,
      `Stress condition: ${input.stress === "uniform-compression" ? "uniform compression" : input.stress === "edge-gradient" ? "compression at one edge and tension at the other" : input.stress === "outstand-gradient" ? "maximum compression at the unsupported edge" : input.stress}.`,
      `Residual stresses: ${input.residual ? residualLabel(input.residual) : "Any — Table 5.2 does not subdivide this row"}.`,
      `b = ${fmt(b, 3)} mm (${bWords}). Panel length and width are not used unless you assigned one of them to b.`,
      `t = ${fmt(t, 3)} mm, fy = ${fmt(fy, 3)} MPa.`,
      `λe = (${fmt(b, 3)} / ${fmt(t, 3)}) × √(${fmt(fy, 3)} / 250) = ${fmt(le, 4)}.`,
      `Table 5.2 row: ${limits.row}.`,
      `λep = ${limits.ep}, λey = ${limits.ey}${limits.ed == null ? ", λed is not given" : `, λed = ${limits.ed}`}.`,
      `λs is this element's λe. λsp = λep and λsy = λey for that same element (Clause 5.2.2).`,
      le <= limits.ep
        ? `λe ≤ λep, so the element is compact.`
        : le <= limits.ey
          ? `λep < λe ≤ λey, so the element is non-compact.`
          : `λe > λey, so the element is slender.`,
    ],
    note: "Classification is not a design resistance. Elastic σcr is not used.",
  }))
  if (limits.ed == null) {
    checks.push(blankCheck({
      id: "deformation", group: "PLATE SLENDERNESS", title: "Deformation slenderness",
      clause: "5.2.5", equation: "λe compared with λed",
      kind: "service", status: "not-applicable", result: "NOT APPLICABLE",
      note: "Table 5.2 does not give λed for this row.",
    }))
  } else if (le > limits.ed) {
    checks.push(blankCheck({
      id: "deformation", group: "PLATE SLENDERNESS", title: "Deformation slenderness",
      clause: "5.2.5", equation: "λe ≤ λed",
      kind: "service", status: "fail", result: `λe ${fmt(le, 3)} > λed ${limits.ed}`,
      steps: [`λed = ${limits.ed} from Table 5.2. Clause 5.2.5 says noticeable service deformations may occur. This is not a reduction of φRu.`],
      note: "Serviceability warning. It does not change the strength capacity.",
    }))
  } else {
    checks.push(blankCheck({
      id: "deformation", group: "PLATE SLENDERNESS", title: "Deformation slenderness",
      clause: "5.2.5", equation: "λe ≤ λed",
      kind: "service", status: "pass", result: `λe ${fmt(le, 3)} ≤ λed ${limits.ed}`,
      note: "Within the Table 5.2 deformation limit.",
    }))
  }

  let be: number | null = null
  if (input.stress !== "uniform-compression") {
    checks.push(blankCheck({
      id: "effective-width", group: "EFFECTIVE WIDTH", title: "Effective width",
      clause: "6.2.4", equation: "be = b (λey/λe) ≤ b",
      status: "not-applicable", result: "NOT APPLICABLE", kind: "classification",
      note: "Clause 6.2.4 and Table 6.2.4 are for a flat compression element. A bending stress gradient is classified with Table 5.2 and is not given this effective width. Clause 5.2.5 does not state a Ze formula for both edges supported with compression at one edge and tension at the other when the element is slender, so Ze is not invented.",
    }))
    return { checks, be, lambda: le }
  }
  if (!input.residual) return { checks, be, lambda: le }
  const ey = lambdaEy624(input.edgesSupported, input.residual)
  if (ey == null) {
    checks.push(data({
      id: "effective-width", group: "EFFECTIVE WIDTH", title: "Effective width",
      clause: "Table 6.2.4", equation: "be = b (λey/λe) ≤ b",
      missing: "Table 6.2.4 has no yield limit for this edge and residual-stress pair.",
    }))
    return { checks, be, lambda: le }
  }
  const bePrimary = Math.min(b, b * (ey / le))
  const steps = [
    `Table 6.2.4 λey = ${ey} for ${input.edgesSupported === "one" ? "one edge (outstand)" : "both edges"}, ${residualLabel(input.residual)}.`,
    `Primary width, Clause 6.2.4: b (λey/λe) = ${fmt(b, 3)} × (${ey} / ${fmt(le, 4)}) = ${fmt(b * ey / le, 3)} mm. ${b * ey / le > b + 1e-6 ? `That exceeds gross width b, so be is limited to b. ` : ""}be = ${fmt(bePrimary, 3)} mm.`,
    `Gross width ${fmt(b, 3)} mm. Ineffective width ${fmt(Math.max(0, b - bePrimary), 3)} mm. This is not an iteration: one flat element in uniform compression has no neutral-axis shift.`,
  ]
  let beUsed = bePrimary
  let equation = "be = b (λey/λe) ≤ b"
  if (input.widthPath === "alternative") {
    if (!pos(input.kb)) {
      checks.push(data({
        id: "effective-width", group: "EFFECTIVE WIDTH", title: "Effective width",
        clause: "6.2.4", equation: "be = b (λey/λe) √(kb/kbo) ≤ b",
        missing: "The alternative width needs kb from a rational elastic buckling analysis of the plate assemblage. FEM σcr is not inserted automatically.",
        steps,
      }))
      return { checks, be: null, lambda: le }
    }
    const k0 = kbo(input.edgesSupported)
    beUsed = Math.min(b, b * (ey / le) * Math.sqrt(input.kb / k0))
    equation = "be = b (λey/λe) √(kb/kbo) ≤ b"
    steps.push(`Alternative, Clause 6.2.4: kbo = ${k0} (${input.edgesSupported === "both" ? "both edges" : "outstand"}). kb = ${fmt(input.kb, 4)} supplied by you, not taken from λFEM.`)
    steps.push(`be = ${fmt(b, 3)} × (${ey}/${fmt(le, 4)}) × √(${fmt(input.kb, 4)}/${k0}) = ${fmt(beUsed, 3)} mm.`)
  } else if (pos(input.kb)) {
    steps.push(`kb = ${fmt(input.kb, 4)} is entered but the primary width is selected. It is not mixed into φNs.`)
  }
  be = beUsed
  checks.push(blankCheck({
    id: "effective-width", group: "EFFECTIVE WIDTH", title: "Effective width",
    clause: "6.2.4", equation, kind: "classification", status: "pass",
    result: `be = ${fmt(beUsed, 3)} mm`,
    steps, note: "be is a compression-element width. It is not φN.",
  }))
  return { checks, be, lambda: le }
}

function axial(input: DesignInput, be: number | null): Check[] {
  if (input.axial == null) {
    return [blankCheck({
      id: "axial", group: "AXIAL", title: "Axial section capacity",
      clause: "6.2.1 / 7.2", equation: "Ns = kf An fy or Nt = min(Ag fy, 0.85 kt An fu)",
      status: "not-checked", result: "NOT CHECKED",
      note: "Axial action is not stated. Choose none, compression or tension. A tensile force is not checked as compression.",
    })]
  }
  if (input.axial === "none") {
    return [blankCheck({
      id: "axial", group: "AXIAL", title: "Axial section capacity",
      clause: "6.1 / 7.1", equation: "N* ≤ φN",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "No axial design force.",
    })]
  }
  const axialScope = outsideMaterial(input.fyMpa, input.thicknessMm)
  if (axialScope) {
    return [scopeRow("axial", "AXIAL", "Axial section capacity", input.axial === "tension" ? "7.2" : "6.2", axialScope)]
  }
  if (!pos(input.clearWidthMm) || !pos(input.thicknessMm) || !pos(input.fyMpa)) {
    return [data({
      id: "axial", group: "AXIAL", title: "Axial section capacity",
      clause: input.axial === "tension" ? "7.2" : "6.2.1",
      equation: input.axial === "tension" ? "Nt = min(Ag fy, 0.85 kt An fu)" : "Ns = kf An fy",
      missing: "Clear width, thickness and fy are required before an axial section capacity can be formed.",
    })]
  }
  const ag = input.clearWidthMm * input.thicknessMm
  if (input.holes == null) {
    return [data({
      id: "axial", group: "AXIAL", title: "Axial section capacity",
      clause: "6.2.1", equation: "An",
      missing: "State that there are no holes, or enter the net area. Gross area is not assumed.",
    })]
  }
  let an = ag
  const holeSteps: string[] = [`Ag = b × t = ${fmt(input.clearWidthMm, 3)} × ${fmt(input.thicknessMm, 3)} = ${fmt(ag, 3)} mm².`]
  if (input.holes === "net") {
    if (!pos(input.anMm2) || !pos(input.fuMpa)) {
      return [data({
        id: "axial", group: "AXIAL", title: "Axial section capacity",
        clause: "6.2.1", equation: "An",
        missing: "Net area and fu are required. Clause 6.2.1 allows Ag only when the hole reduction is less than 100[1 − fy/(0.85 fu)] percent.",
      })]
    }
    if (input.anMm2 > ag) {
      return [blankCheck({
        id: "axial", group: "AXIAL", title: "Axial section capacity",
        clause: "6.2.1", equation: "An ≤ Ag",
        status: "invalid", result: "INVALID INPUT",
        note: `Net area ${fmt(input.anMm2, 3)} mm² is greater than gross area ${fmt(ag, 3)} mm². That is not clamped to Ag.`,
        steps: holeSteps,
      })]
    }
    const limit = 100 * (1 - input.fyMpa / (0.85 * input.fuMpa))
    const reduction = 100 * (ag - input.anMm2) / ag
    an = reduction < limit ? ag : input.anMm2
    holeSteps.push(`Hole reduction = ${fmt(reduction, 3)} %. Clause 6.2.1 threshold = ${fmt(limit, 3)} %. An used = ${fmt(an, 3)} mm².`)
  } else {
    holeSteps.push("No holes entered, so An = Ag.")
  }
  if (input.axial === "tension") {
    if (!pos(input.fuMpa) || !pos(input.kt)) {
      return [data({
        id: "axial", group: "AXIAL", title: "Tension section capacity",
        clause: "7.2", equation: "Nt = min(Ag fy, 0.85 kt An fu)",
        missing: "fu and kt are required. kt = 1.0 only where Clause 7.3.1 end connections are satisfied. It is not assumed.",
        steps: holeSteps,
      })]
    }
    const nYield = ag * input.fyMpa
    const fracture = 0.85 * input.kt * an * input.fuMpa
    const nt = Math.min(nYield, fracture)
    const { phi, source } = phiOf("tension")
    const design = phi * nt
    const hasAction = input.nStarN != null && input.nStarN < 0
    const action = hasAction ? -input.nStarN! : null
    const used = action == null ? null : utilisation(action, design)
    return [blankCheck({
      id: "axial", group: "AXIAL", title: "Tension section capacity",
      clause: "7.1 and 7.2", equation: "Nt = min(Ag fy, 0.85 kt An fu); N* ≤ φ Nt",
      status: used?.status ?? "not-checked",
      result: action == null ? `φNt = ${kn(design)}; action not entered` : `${fmt(used!.ratio, 3)}`,
      nominal: nt, nominalUnit: "N", phi, phiSource: source, designCapacity: design,
      action, utilisation: used?.ratio ?? null,
      steps: [
        ...holeSteps,
        `Ag fy = ${kn(nYield)}. 0.85 kt An fu = 0.85 × ${fmt(input.kt, 3)} × ${fmt(an, 3)} × ${fmt(input.fuMpa, 3)} = ${kn(fracture)}.`,
        `Nt = ${kn(nt)}. φ = 0.90. φNt = ${kn(design)}.`,
        "Compression slenderness is not used as a tensile resistance.",
      ],
      note: action == null ? "Enter the tensile design force as a negative N* (compression positive)." : "Pure tension is not reported as a buckling capacity.",
    })]
  }
  if (be == null) {
    return [data({
      id: "axial", group: "AXIAL", title: "Compression section capacity",
      clause: "6.2.2", equation: "kf = Ae/Ag; Ns = kf An fy",
      missing: "Effective width is not available, so Ae cannot be formed. Uniform compression and Table 6.2.4 are required. Member capacity Nc (Clause 6.3) is outside a plate panel: le, r and αb are not panel properties.",
      steps: holeSteps,
    })]
  }
  const ae = be * input.thicknessMm
  const kf = ae / ag
  if (!(kf > 0) || kf > 1 + 1e-9) {
    return [blankCheck({
      id: "axial", group: "AXIAL", title: "Compression section capacity",
      clause: "6.2.2", equation: "kf = Ae/Ag",
      status: "invalid", result: "INVALID INPUT",
      note: `kf = Ae/Ag = ${fmt(kf, 4)} is outside (0, 1]. It is not clamped.`,
      steps: holeSteps,
    })]
  }
  const ns = kf * an * input.fyMpa
  const { phi, source } = phiOf("compression")
  const design = phi * ns
  const action = input.nStarN != null && input.nStarN > 0 ? input.nStarN : null
  const used = action == null ? null : utilisation(action, design)
  return [blankCheck({
    id: "axial", group: "AXIAL", title: "Compression section capacity",
    clause: "6.2.1 and 6.2.2", equation: "kf = Ae/Ag; Ns = kf An fy; N* ≤ φ Ns",
    status: used?.status ?? "not-checked",
    result: action == null ? `φNs = ${kn(design)}; N* not entered` : `${fmt(used!.ratio, 3)}`,
    nominal: ns, nominalUnit: "N", phi, phiSource: source, designCapacity: design,
    action, utilisation: used?.ratio ?? null,
    steps: [
      ...holeSteps,
      `Ae = be × t = ${fmt(be, 3)} × ${fmt(input.thicknessMm, 3)} = ${fmt(ae, 3)} mm².`,
      `kf = Ae/Ag = ${fmt(kf, 4)}.`,
      `Ns = kf An fy = ${fmt(kf, 4)} × ${fmt(an, 3)} × ${fmt(input.fyMpa, 3)} = ${kn(ns)}.`,
      `φ = 0.90. Design section capacity φNs = ${kn(design)}.`,
      "Clause 6.3 member capacity Nc = αc Ns is not evaluated for the panel. It is used only inside bearing and stiffener checks where the clause fixes αb, kf and the slenderness.",
    ],
    note: "Nominal Ns and design φNs are kept separate. Elastic λ is not N*.",
  })]
}

function webThickness(input: DesignInput): Check {
  if (input.role !== "web") {
    return blankCheck({
      id: "web-thickness", group: "WEB", title: "Minimum web thickness",
      clause: "5.10", equation: "tw limits of Clause 5.10",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "The plate is not identified as a web.",
    })
  }
  const webScope = outsideMaterial(input.fyMpa, input.twMm)
  if (webScope) return scopeRow("web-thickness", "WEB", "Minimum web thickness", "1.1.2", webScope)
  if (!pos(input.d1Mm) || !pos(input.twMm) || !pos(input.fyMpa) || !input.webBound && input.stiffening !== "transverse" && input.stiffening !== "longitudinal") {
    return data({
      id: "web-thickness", group: "WEB", title: "Minimum web thickness",
      clause: "5.10.1", equation: "tw ≥ (d1/180) √(fy/250) or the stiffened alternative",
      missing: "Required for a web: clear depth d1, web thickness tw, fy, and whether both longitudinal edges are flanges or one edge is free.",
    })
  }
  const root = Math.sqrt(input.fyMpa / 250)
  const d1 = input.d1Mm
  const tw = input.twMm
  if (input.plasticWeb) {
    const min = (d1 / 82) * root
    const ok = tw + 1e-9 >= min
    return blankCheck({
      id: "web-thickness", group: "WEB", title: "Plastic web thickness",
      clause: "5.10.6", equation: "tw ≥ (d1/82) √(fy/250)",
      status: ok ? "pass" : "fail", result: `tw ${fmt(tw, 3)} mm vs ${fmt(min, 3)} mm`,
      steps: [`Minimum = (${fmt(d1, 3)} / 82) × √(${fmt(input.fyMpa, 3)}/250) = ${fmt(min, 3)} mm.`],
      note: "Used only because plastic design of the member was selected.",
    })
  }
  if (input.stiffening === "unstiffened" || input.stiffening == null) {
    if (!input.webBound) {
      return data({
        id: "web-thickness", group: "WEB", title: "Minimum web thickness",
        clause: "5.10.1", equation: "d1/180 or d1/90",
        missing: "Say whether the unstiffened web is bounded by flanges on both longitudinal sides or by a free edge on one side.",
      })
    }
    const denom = input.webBound === "both-flanges" ? 180 : 90
    const min = (d1 / denom) * root
    return blankCheck({
      id: "web-thickness", group: "WEB", title: "Unstiffened web thickness",
      clause: "5.10.1", equation: `tw ≥ (d1/${denom}) √(fy/250)`,
      status: tw + 1e-9 >= min ? "pass" : "fail",
      result: `tw ${fmt(tw, 3)} mm vs ${fmt(min, 3)} mm`,
      steps: [`d1 = ${fmt(d1, 3)} mm, ignoring fillets. Minimum = ${fmt(min, 3)} mm.`],
      note: input.stiffening == null ? "Stiffening was not selected, so the unstiffened limit is shown and the shear check stays incomplete." : "Clause 5.10.1.",
    })
  }
  if (!pos(input.sMm)) {
    return data({
      id: "web-thickness", group: "WEB", title: "Stiffened web thickness",
      clause: "5.10.4", equation: "tw limit from s/d1",
      missing: "Transverse stiffener spacing s is required. It is not taken from the FEM stiffener lines.",
    })
  }
  const ratio = input.sMm / d1
  if (input.stiffening === "transverse") {
    if (!pos(input.dpMm)) {
      return data({
        id: "web-thickness", group: "WEB", title: "Stiffened web thickness",
        clause: "5.10.4", equation: "unstiffened when s/dp > 3",
        missing: "Clause 5.10.4 treats the web as unstiffened when s/dp > 3. Enter panel depth dp. d1 is not substituted for dp.",
      })
    }
    const sOverDp = input.sMm / input.dpMm
    if (sOverDp > 3) {
      if (!input.webBound) {
        return data({
          id: "web-thickness", group: "WEB", title: "Web treated as unstiffened",
          clause: "5.10.4", equation: "s/dp > 3 uses Clause 5.10.1",
          missing: "s/dp exceeds 3, so the unstiffened thickness of Clause 5.10.1 applies. Say whether both edges are flanges or one edge is free.",
        })
      }
      const min = input.webBound === "one-free" ? (d1 / 90) * root : (d1 / 180) * root
      const ok = tw + 1e-9 >= min
      return blankCheck({
        id: "web-thickness", group: "WEB", title: "Web treated as unstiffened",
        clause: "5.10.4", equation: "s/dp > 3 is unstiffened; thickness from 5.10.1",
        status: ok ? "pass" : "fail",
        result: `tw ${fmt(tw, 3)} mm vs ${fmt(min, 3)} mm`,
        steps: [`s/dp = ${fmt(sOverDp, 4)} > 3. Minimum from Clause 5.10.1 is ${fmt(min, 3)} mm. The trigger uses dp, not d1.`],
        note: "Clause 5.10.4. d1 remains the depth in the thickness expression.",
      })
    }
    if (ratio > 3) {
      return blankCheck({
        id: "web-thickness", group: "WEB", title: "Transversely stiffened web thickness",
        clause: "5.10.4", equation: "1.0 ≤ s/d1 ≤ 3.0",
        status: "out-of-scope", result: "OUTSIDE IMPLEMENTED SCOPE",
        note: `s/dp = ${fmt(sOverDp, 4)} is not greater than 3, so the web is not treated as unstiffened, but s/d1 = ${fmt(ratio, 4)} is above 3. Clause 5.10.4(a) stops at s/d1 = 3. d1 was not substituted for dp, and (d1/200) was not applied outside that range.`,
      })
    }
    let min: number
    let clauseBit: string
    if (ratio >= 1) {
      min = (d1 / 200) * root
      clauseBit = "(d1/200) √(fy/250) for 1.0 ≤ s/d1 ≤ 3.0"
    } else if (ratio > 0.74) {
      min = (input.sMm / 200) * root
      clauseBit = "(s/200) √(fy/250) for 0.74 < s/d1 < 1.0"
    } else {
      min = (d1 / 270) * root
      clauseBit = "(d1/270) √(fy/250) for s/d1 ≤ 0.74"
    }
    return blankCheck({
      id: "web-thickness", group: "WEB", title: "Transversely stiffened web thickness",
      clause: "5.10.4", equation: clauseBit,
      status: tw + 1e-9 >= min ? "pass" : "fail",
      result: `tw ${fmt(tw, 3)} mm vs ${fmt(min, 3)} mm`,
      steps: [`s/d1 = ${fmt(ratio, 4)}. Minimum tw = ${fmt(min, 3)} mm.`],
      note: "No longitudinal stiffeners in this thickness clause.",
    })
  }
  if (!pos(input.d2Mm)) {
    return data({
      id: "web-thickness", group: "WEB", title: "Longitudinally stiffened web thickness",
      clause: "5.10.5", equation: "tw limit using d2",
      missing: "d2 is twice the clear distance from the neutral axis to the compression flange. It is not assumed equal to d1.",
    })
  }
  const where = input.longWhere
  if (where == null || where === "none") {
    return data({
      id: "web-thickness", group: "WEB", title: "Longitudinally stiffened web thickness",
      clause: "5.10.5", equation: "stiffener position",
      missing: "Say whether the longitudinal stiffener is at 0.2 d2 from the compression flange, at the neutral axis, or both. The clause applies when that stiffener is required.",
    })
  }
  let min: number
  let equation: string
  if (where === "neutral") {
    if (ratio > 1.5) {
      return blankCheck({
        id: "web-thickness", group: "WEB", title: "Neutral-axis stiffener thickness limit",
        clause: "5.10.5", equation: "tw ≥ (d1/400) √(fy/250) when s/d1 ≤ 1.5",
        status: "not-applicable", result: "NOT APPLICABLE",
        note: "The additional neutral-axis limit is stated for s/d1 ≤ 1.5. This spacing is larger, so that limit is not applied. The 0.2 d2 set is a separate requirement.",
      })
    }
    min = (d1 / 400) * root
    equation = "tw ≥ (d1/400) √(fy/250)"
  } else {
    if (ratio >= 1 && ratio <= 2.4) {
      min = (d1 / 250) * root
      equation = "(d1/250) √(fy/250) for 1.0 ≤ s/d1 ≤ 2.4"
    } else if (ratio >= 0.74 && ratio <= 1) {
      min = (input.sMm / 250) * root
      equation = "(s/250) √(fy/250) for 0.74 ≤ s/d1 ≤ 1.0"
    } else if (ratio < 0.74) {
      min = (d1 / 340) * root
      equation = "(d1/340) √(fy/250) for s/d1 < 0.74"
    } else {
      return blankCheck({
        id: "web-thickness", group: "WEB", title: "Longitudinally stiffened web thickness",
        clause: "5.10.5", equation: "s/d1 > 2.4",
        status: "out-of-scope", result: "OUTSIDE IMPLEMENTED SCOPE",
        note: "Clause 5.10.5 states the 0.2 d2 thickness limits up to s/d1 = 2.4. A wider spacing is not given a substitute here.",
      })
    }
    if (where === "both" && ratio <= 1.5) min = Math.max(min, (d1 / 400) * root)
  }
  return blankCheck({
    id: "web-thickness", group: "WEB", title: "Longitudinally stiffened web thickness",
    clause: "5.10.5", equation,
    status: tw + 1e-9 >= min ? "pass" : "fail",
    result: `tw ${fmt(tw, 3)} mm vs ${fmt(min, 3)} mm`,
    steps: [`s/d1 = ${fmt(ratio, 4)}. d2 = ${fmt(input.d2Mm, 3)} mm is recorded and is not used in the thickness formula. Minimum tw = ${fmt(min, 3)} mm.`],
    note: "d2 locates the stiffener. The thickness formula uses d1 and s as written.",
  })
}

function shearCheck(input: DesignInput): { check: Check; vw: number | null; alphaV: number | null; dp: number | null; tw: number | null } {
  const empty = { vw: null as number | null, alphaV: null as number | null, dp: null as number | null, tw: null as number | null }
  if (input.role !== "web") {
    return { check: blankCheck({
      id: "shear", group: "SHEAR", title: "Web shear",
      clause: "5.11", equation: "V* ≤ φ Vv",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "Clause 5.11 is a web shear check. An element that is not a web does not receive it. Elastic τcr is not φVv.",
    }), ...empty }
  }
  const shearScope = outsideMaterial(input.fyMpa, input.twMm)
  if (shearScope) {
    return { check: scopeRow("shear", "SHEAR", "Web shear", "1.1.2", shearScope), ...empty }
  }
  if (!pos(input.dpMm) || !pos(input.twMm) || !pos(input.fyMpa) || input.webGross !== "gross" || !input.stiffening || !input.shearMode) {
    return { check: data({
      id: "shear", group: "SHEAR", title: "Web shear",
      clause: "5.11", equation: "Vw = 0.6 fy Aw; Vu = Vw or Vb",
      missing: "Required: panel depth dp, web thickness tw, fy, confirmation that Aw is the gross web area, uniform or non-uniform shear, and unstiffened / transverse / longitudinal stiffening. dp is not copied from the panel height.",
    }), ...empty }
  }
  const dp = input.dpMm
  const tw = input.twMm
  const fy = input.fyMpa
  const aw = dp * tw
  const vw = shearYield(fy, aw)
  const ratio = dp / tw
  const limit = stockyLimit(fy)
  const stocky = ratio <= limit
  const steps = [
    `Aw = dp × tw = ${fmt(dp, 3)} × ${fmt(tw, 3)} = ${fmt(aw, 3)} mm², gross web, no holes confirmed.`,
    `Vw = 0.6 fy Aw = 0.6 × ${fmt(fy, 3)} × ${fmt(aw, 3)} = ${kn(vw)} (Clause 5.11.4).`,
    `dp/tw = ${fmt(ratio, 3)}. 82/√(fy/250) = ${fmt(limit, 3)}.`,
  ]
  let vu = vw
  let alphaV: number | null = null
  const sOver = input.sMm != null && dp > 0 ? input.sMm / dp : null
  if (input.stiffening !== "unstiffened" && sOver != null && sOver > 0 && sOver <= 3) {
    alphaV = alphaVStiffened(ratio, fy, sOver)
  }
  if (!stocky) {
    const stiffened = input.stiffening !== "unstiffened" && sOver != null && sOver <= 3 && sOver > 0
    if (input.stiffening !== "unstiffened" && (sOver == null || !(sOver > 0))) {
      return { check: data({
        id: "shear", group: "SHEAR", title: "Stiffened web shear",
        clause: "5.11.5.2", equation: "Vb = αv αd αf Vw ≤ Vw",
        missing: "Stiffener spacing s is required and must be positive. Spacing is not read from the FEM model.",
        steps,
      }), vw, alphaV, dp, tw }
    }
    if (!stiffened) {
      alphaV = alphaVUnstiffened(ratio, fy)
      const vb = Math.min(vw, alphaV * vw)
      vu = vb
      steps.push(input.stiffening !== "unstiffened"
        ? `s/dp = ${fmt(sOver ?? 0, 3)} > 3, so Clause 5.10.4 treats the web as unstiffened.`
        : "Unstiffened web, Clause 5.11.5.1.")
      steps.push(`αv = [82 / ((dp/tw) √(fy/250))]² = ${fmt(alphaV, 4)}.`)
      steps.push(`Vb = αv Vw ≤ Vw = ${kn(vb)}. Vu = Vb because dp/tw exceeds the yield limit.`)
    } else {
      alphaV = alphaVStiffened(ratio, fy, sOver!)
      const ad = alphaD(alphaV, sOver!, input.endPanel)
      let af = 1
      let afNote = "αf = 1.0 by Clause 5.11.5.2(a)."
      if (input.stiffening === "longitudinal") {
        afNote = "Longitudinal stiffeners are present, so the flange formula 5.11.5.2(b) is not used. αf = 1.0. A rational value under 5.11.5.2(c) is not supplied."
      } else if (input.alphaF === "flange") {
        if (!pos(input.bfoMm) || !pos(input.tfMm) || !pos(input.d1Mm)) {
          return { check: data({
            id: "shear", group: "SHEAR", title: "Stiffened web shear",
            clause: "5.11.5.2(b)", equation: "αf = 1.6 − 0.6/√[1 + 40 bfo tf²/(d1² tw)]",
            missing: "Flange restraint needs bfo (the least of 12 tf/√(fy/250), the flange outstand from the web mid-plane, and half the clear distance between webs), plus tf and d1.",
            steps,
          }), vw, alphaV, dp, tw }
        }
        af = alphaFFlange(input.bfoMm, input.tfMm, input.d1Mm, tw)
        afNote = `αf = 1.6 − 0.6/√[1 + 40×${fmt(input.bfoMm, 3)}×${fmt(input.tfMm, 3)}²/(${fmt(input.d1Mm, 3)}²×${fmt(tw, 3)})] = ${fmt(af, 4)}. bfo must already be the least of the three Clause 5.11.5.2(b) lengths.`
      }
      const adText = input.endPanel ? "αd = 1.0 as required by Clause 5.15.2.2 for the end panel." : `αd = 1 + (1−αv)/(1.15 αv √(1+(s/dp)²)) = ${fmt(ad, 4)}.`
      const vb = Math.min(vw, alphaV * ad * af * vw)
      vu = vb
      steps.push(`s/dp = ${fmt(sOver!, 4)} ≤ 3, Clause 5.11.5.2.`)
      steps.push(`αv = ${fmt(alphaV, 4)} (capped at 1). ${adText} ${afNote}`)
      steps.push(`Vb = αv αd αf Vw ≤ Vw = ${kn(vb)}.`)
    }
  } else {
    steps.push("dp/tw is within the Clause 5.11.2 yield limit, so Vu = Vw. Buckling is not used for Vu.")
    if (alphaV != null) steps.push(`Stiffened αv = ${fmt(alphaV, 4)} is kept for Clause 5.15.3 only. It does not reduce Vu.`)
  }
  let vv = vu
  if (input.shearMode === "non-uniform") {
    if (!pos(input.fvmMpa) || !pos(input.fvaMpa)) {
      return { check: data({
        id: "shear", group: "SHEAR", title: "Non-uniform web shear",
        clause: "5.11.3", equation: "Vv = 2 Vu / (0.9 + f*vm/f*va) ≤ Vu",
        missing: "Maximum and average design shear stresses from a rational elastic analysis are required. They are not taken from the FEM eigenmode.",
        steps,
      }), vw, alphaV, dp, tw }
    }
    vv = Math.min(vu, 2 * vu / (0.9 + input.fvmMpa / input.fvaMpa))
    steps.push(`Clause 5.11.3: f*vm = ${fmt(input.fvmMpa, 3)} MPa, f*va = ${fmt(input.fvaMpa, 3)} MPa. Vv = ${kn(vv)}.`)
  } else {
    steps.push("Approximately uniform shear, Clause 5.11.2, so Vv = Vu.")
  }
  const { phi, source } = phiOf("shear")
  const design = phi * vv
  const action = pos(input.vStarN) || input.vStarN === 0 ? input.vStarN : null
  const used = action == null ? null : utilisation(action, design)
  steps.push(`Nominal Vv = ${kn(vv)}. φ = 0.90. Design shear capacity φVv = ${kn(design)}.`)
  if (action != null) steps.push(`V* = ${kn(action)}. V*/φVv = ${fmt(used!.ratio, 4)}.`)
  return { check: blankCheck({
    id: "shear", group: "SHEAR", title: stocky ? "Shear yield" : "Shear buckling",
    clause: stocky ? "5.11.2 and 5.11.4" : "5.11.5",
    equation: "V* ≤ φ Vv, with Vv from uniform or non-uniform shear",
    status: used?.status ?? "not-checked",
    result: action == null ? `φVv = ${kn(design)}; V* not entered` : `${fmt(used!.ratio, 3)}`,
    nominal: vv, nominalUnit: "N", phi, phiSource: source, designCapacity: design,
    action, utilisation: used?.ratio ?? null, steps,
    note: "Elastic τcr is not this capacity. Nominal Vv and design φVv are separate.",
  }), vw, alphaV, dp, tw }
}

function interaction(input: DesignInput, shearDesign: number | null, shearNominal: number | null): Check {
  if (input.role !== "web") {
    return blankCheck({
      id: "interaction", group: "INTERACTION", title: "Shear and bending",
      clause: "5.12", equation: "V* ≤ φ Vvm",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "Clause 5.12 is for a web with bending. It is not applied to a plate element.",
    })
  }
  if (input.interaction == null) {
    return blankCheck({
      id: "interaction", group: "INTERACTION", title: "Shear and bending",
      clause: "5.12", equation: "5.12.2 or 5.12.3",
      status: "not-checked", result: "NOT CHECKED",
      note: "Choose no bending, the flange proportioning method, or the section interaction method. Neither is assumed.",
    })
  }
  if (input.interaction === "none") {
    return blankCheck({
      id: "interaction", group: "INTERACTION", title: "Shear and bending",
      clause: "5.12", equation: "V* ≤ φ Vv",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "No bending design action is identified, so Clause 5.12 is not applied. Shear alone remains Clause 5.11.",
    })
  }
  if (shearNominal == null || shearDesign == null) {
    return data({
      id: "interaction", group: "INTERACTION", title: "Shear and bending",
      clause: "5.12", equation: "Vvm from Vv",
      missing: "Web shear capacity is not available, so the interaction cannot start.",
    })
  }
  const { phi, source } = phiOf("bending")
  if (input.interaction === "proportioning") {
    if (!pos(input.afeMm2) || !pos(input.afgMm2) || !pos(input.afnMm2) || !pos(input.dfMm) || !pos(input.flangeFyMpa) || !pos(input.flangeFuMpa) || input.mStarNmm == null) {
      return data({
        id: "interaction", group: "INTERACTION", title: "Proportioning method",
        clause: "5.12.2", equation: "Mf = Afm df fy",
        missing: "Required: compression-flange effective area from Clause 6.2.2, flange gross area, flange net area, fu, fy, distance between flange centroids, and M*. The plate model is not turned into flanges.",
      })
    }
    const tensionCap = Math.min(input.afgMm2, 0.85 * input.afnMm2 * input.flangeFuMpa / input.flangeFyMpa)
    const afm = Math.min(input.afeMm2, tensionCap)
    const mf = afm * input.dfMm * input.flangeFyMpa
    const designM = phi * mf
    const mRatio = input.mStarNmm / designM
    const steps = [
      `Tension-side limit = min(Afg, 0.85 Afn fu/fy) = ${fmt(tensionCap, 3)} mm².`,
      `Afm = min(compression effective area, tension-side limit) = ${fmt(afm, 3)} mm².`,
      `Mf = Afm df fy = ${kn(mf)}·mm / 1e6 → moment ${fmt(mf / 1e6, 3)} kN·m.`,
      `φ = 0.90. φMf = ${fmt(designM / 1e6, 3)} kN·m. M* = ${fmt(input.mStarNmm / 1e6, 3)} kN·m.`,
    ]
    if (mRatio > 1) {
      return blankCheck({
        id: "interaction", group: "INTERACTION", title: "Proportioning method",
        clause: "5.12.2", equation: "M* ≤ φ Mf, then Vvm = Vv",
        status: "fail", result: `${fmt(mRatio, 3)}`,
        phi, phiSource: source, utilisation: mRatio, action: input.mStarNmm, designCapacity: designM,
        steps: [...steps, "M* exceeds φMf, so Clause 5.12.2 does not grant Vvm = Vv."],
        note: "The flanges-only moment capacity is exceeded.",
      })
    }
    const vAction = input.vStarN
    const used = vAction == null ? null : utilisation(vAction, shearDesign)
    return blankCheck({
      id: "interaction", group: "INTERACTION", title: "Proportioning method",
      clause: "5.12.2", equation: "M* ≤ φ Mf and V* ≤ φ Vv",
      status: used?.status ?? "not-checked",
      result: used ? `${fmt(Math.max(used.ratio, mRatio), 3)}` : `M*/φMf = ${fmt(mRatio, 3)}; V* not entered`,
      phi, phiSource: source, nominal: shearNominal, nominalUnit: "N", designCapacity: shearDesign,
      action: vAction, utilisation: used ? Math.max(used.ratio, mRatio) : null,
      steps: [...steps, "M* ≤ φMf, so Vvm = Vv and the shear design capacity remains φVv.", used ? `V*/φVv = ${fmt(used.ratio, 4)}.` : "V* was not entered."],
      note: "The reported utilisation needs both M* and V*. A missing action is not a governing ratio.",
    })
  }
  if (!pos(input.msNmm) || input.mStarNmm == null) {
    return data({
      id: "interaction", group: "INTERACTION", title: "Section interaction",
      clause: "5.12.3", equation: "Vvm = Vv [2.2 − 1.6 M*/(φ Ms)]",
      missing: "M* and the nominal section moment capacity Ms from Clause 5.2 are required. Ms is not calculated from the bare plate, and a segment without full lateral restraint (Clause 5.6) is outside this check.",
    })
  }
  const designM = phi * input.msNmm
  const mRatio = input.mStarNmm / designM
  let vvm = shearNominal
  const steps = [
    `Ms = ${fmt(input.msNmm / 1e6, 4)} kN·m, entered from a Clause 5.2 section. φMs = ${fmt(designM / 1e6, 4)} kN·m.`,
    `M* = ${fmt(input.mStarNmm / 1e6, 4)} kN·m. M*/φMs = ${fmt(mRatio, 4)}.`,
  ]
  if (mRatio > 1) {
    return blankCheck({
      id: "interaction", group: "INTERACTION", title: "Section interaction",
      clause: "5.12.3", equation: "formula stated only for M* ≤ φ Ms",
      status: "fail", result: `${fmt(mRatio, 3)}`,
      phi, phiSource: source, utilisation: mRatio,
      steps: [...steps, "M* > φMs. Clause 5.12.3 does not define Vvm above that limit."],
      note: "Bending section capacity is exceeded. Lateral-buckling member capacity is not evaluated.",
    })
  }
  if (input.mStarNmm > 0.75 * designM) {
    vvm = shearNominal * (2.2 - (1.6 * input.mStarNmm) / designM)
    steps.push(`0.75 φMs < M* ≤ φMs, so Vvm = Vv [2.2 − 1.6 M*/(φ Ms)] = ${kn(vvm)}.`)
  } else {
    steps.push("M* ≤ 0.75 φMs, so Vvm = Vv.")
  }
  const designV = phi * vvm
  const used = input.vStarN == null ? null : utilisation(input.vStarN, designV)
  const ratio = used ? Math.max(used.ratio, mRatio) : null
  return blankCheck({
    id: "interaction", group: "INTERACTION", title: "Section interaction",
    clause: "5.12.3", equation: "V* ≤ φ Vvm",
    status: used?.status ?? "not-checked",
    result: used ? `${fmt(ratio!, 3)}` : `M*/φMs = ${fmt(mRatio, 3)}; φVvm = ${kn(designV)}; V* not entered`,
    nominal: vvm, nominalUnit: "N", phi, phiSource: source, designCapacity: designV,
    action: input.vStarN, utilisation: ratio,
    steps: [...steps, `φ = 0.90. φVvm = ${kn(designV)}.`],
    note: "φ is the bending capacity factor on Ms and the shear factor on Vvm, both 0.90 from Table 3.4. They are not γM.",
  })
}

function bearing(input: DesignInput): Check[] {
  if (input.role !== "web") {
    return [blankCheck({
      id: "bearing", group: "BEARING", title: "Web bearing",
      clause: "5.13", equation: "R* ≤ φ Rb",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "The elastic patch load is not a Clause 5.13 bearing check, and this plate is not identified as a web.",
    })]
  }
  if (input.bearing == null) {
    return [blankCheck({
      id: "bearing", group: "BEARING", title: "Web bearing",
      clause: "5.13", equation: "Rb = min(Rby, Rbb)",
      status: "not-checked", result: "NOT CHECKED",
      note: "Bearing is not addressed. Choose none, an I or C web, or an RHS. The FEM patch eigenvalue is not Rb.",
    })]
  }
  if (input.bearing === "none") {
    return [blankCheck({
      id: "bearing", group: "BEARING", title: "Web bearing",
      clause: "5.13", equation: "R* ≤ φ Rb",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "No compressive bearing force is identified.",
    })]
  }
  if (input.bearing === "rhs") {
    return [blankCheck({
      id: "bearing", group: "BEARING", title: "RHS web bearing",
      clause: "5.13.3 and Figure 5.13.1.3", equation: "Rby = 2 bb t fy αp",
      status: "out-of-scope", result: "OUTSIDE IMPLEMENTED SCOPE",
      note: "The RHS coefficient αp and the interior/end bearing widths in Figure 5.13.1.3 are not implemented. Clause 5.13.5 combined bending and bearing is also not implemented. No RHS capacity is reported.",
    })]
  }
  const bearingScope = outsideMaterial(input.fyMpa, input.twMm)
  if (bearingScope) return [scopeRow("bearing", "BEARING", "I or C web bearing", "1.1.2", bearingScope)]
  if (input.stiffening == null) {
    return [data({
      id: "bearing", group: "BEARING", title: "I or C web bearing",
      clause: "5.13.4", equation: "Rbb for a web without transverse stiffeners",
      missing: "Clause 5.13.4 applies to an I-section or C-section web without transverse stiffeners. State that the web is unstiffened, or design a load-bearing stiffener to Clause 5.14. The patch eigenvalue is not Rbb.",
    })]
  }
  if (input.stiffening !== "unstiffened") {
    return [blankCheck({
      id: "bearing", group: "BEARING", title: "I or C web bearing",
      clause: "5.13.4", equation: "Rbb for a web without transverse stiffeners",
      status: "out-of-scope", result: "OUTSIDE IMPLEMENTED SCOPE",
      note: "A bearing force is identified, but Clause 5.13.4 does not cover a transversely or longitudinally stiffened web. No unstiffened φRb is reported. Clause 5.14 is the stiffener path. Appendix I is informative and is not φRb.",
    })]
  }
  if (!pos(input.twMm) || !pos(input.fyMpa) || !pos(input.d1Mm) || input.flangesRestrained == null) {
    return [data({
      id: "bearing", group: "BEARING", title: "I or C web bearing",
      clause: "5.13.3 and 5.13.4", equation: "Rby = 1.25 bbf tw fy; Rbb from Section 6",
      missing: "Required: tw, fy, clear depth d1, and whether both flanges are restrained against lateral movement (2.5 d1/tw) or not (5.0 d1/tw).",
    })]
  }
  let bbf = input.bbfMm
  let bb = input.bbMm
  const steps: string[] = []
  if (input.deriveWidth) {
    if (!pos(input.bsMm) || !pos(input.bearingTfMm) || !input.bearingPlace) {
      return [data({
        id: "bearing", group: "BEARING", title: "Bearing dispersion",
        clause: "5.13.1 and Figure 5.13.1.1", equation: "bbf = bs + 5 tf",
        missing: "Dispersion needs the stiff bearing length bs, flange thickness tf, and interior or end.",
      })]
    }
    bbf = input.bsMm + 5 * input.bearingTfMm
    bb = input.bearingPlace === "interior" ? bbf + input.d1Mm : bbf + input.d1Mm / 2
    steps.push(`Figure 5.13.1.1: bbf = bs + 5 tf = ${fmt(input.bsMm, 3)} + 5×${fmt(input.bearingTfMm, 3)} = ${fmt(bbf, 3)} mm (2.5:1 through the flange, both sides).`)
    steps.push(input.bearingPlace === "interior"
      ? `Interior 1:1 dispersion to the neutral axis: bb = bbf + d1 = ${fmt(bb, 3)} mm.`
      : `End 1:1 dispersion on the span side only: bb = bbf + d1/2 = ${fmt(bb, 3)} mm. If the member end cuts this width, enter bb directly instead.`)
  }
  if (!pos(bbf) || !pos(bb)) {
    return [data({
      id: "bearing", group: "BEARING", title: "I or C web bearing",
      clause: "5.13.3", equation: "Rby = 1.25 bbf tw fy",
      missing: "Enter bbf and bb, or derive them from bs, tf and interior/end. bbf is the bearing width at the web shown in Figure 5.13.1.1.",
      steps,
    })]
  }
  const rby = 1.25 * bbf * input.twMm * input.fyMpa
  const leOverR = (input.flangesRestrained ? 2.5 : 5) * input.d1Mm / input.twMm
  const area = input.twMm * bb
  const column = columnCapacity({ leOverR, fyMpa: input.fyMpa, areaMm2: area, alphaB: 0.5, kf: 1 })
  const rbb = column.nc
  const rb = Math.min(rby, rbb)
  const { phi, source } = phiOf("bearing")
  const design = phi * rb
  const action = input.rStarN
  const used = action == null ? null : utilisation(action, design)
  steps.push(`Rby = 1.25 × ${fmt(bbf, 3)} × ${fmt(input.twMm, 3)} × ${fmt(input.fyMpa, 3)} = ${kn(rby)} (Clause 5.13.3).`)
  steps.push(`Clause 5.13.4: αb = 0.5, kf = 1.0, area = tw bb = ${fmt(area, 3)} mm².`)
  steps.push(`le/r = ${input.flangesRestrained ? "2.5" : "5.0"} d1/tw = ${fmt(leOverR, 3)}.`)
  steps.push(`λn = (le/r) √(kf) √(fy/250) = ${fmt(column.lambdaN, 3)}. αc = ${fmt(column.alpha, 4)} from Clause 6.3.3.`)
  steps.push(`Rbb = αc Ns = ${kn(rbb)}. Rb = min(Rby, Rbb) = ${kn(rb)}.`)
  steps.push(`φ = 0.90. φRb = ${kn(design)}.`)
  return [blankCheck({
    id: "bearing", group: "BEARING", title: "I or C web bearing",
    clause: "5.13.2", equation: "Rb = min(Rby, Rbb); R* ≤ φ Rb",
    status: used?.status ?? "not-checked",
    result: action == null ? `φRb = ${kn(design)}; R* not entered` : `${fmt(used!.ratio, 3)}`,
    nominal: rb, nominalUnit: "N", phi, phiSource: source, designCapacity: design,
    action, utilisation: used?.ratio ?? null, steps,
    note: "The elastic patch buckling load is not Rbb. Yield and buckling are both calculated; the lesser nominal value is used.",
  })]
}

function gammaOf(arrangement: DesignInput["arrangement"]): number | null {
  if (arrangement === "pair") return 1
  if (arrangement === "single-angle") return 1.8
  if (arrangement === "single-plate") return 2.4
  return null
}

function stiffenerSection(input: DesignInput, fy: number, tw: number): { ok: true; area: number; inertia: number; ry: number; steps: string[] } | { ok: false; missing: string } {
  if (!pos(input.sMm)) return { ok: false, missing: "Adjacent stiffener spacing s is required so the web length each side can be limited to s/2." }
  const each = Math.min(17.5 * tw / Math.sqrt(fy / 250), input.sMm / 2)
  const webWidth = 2 * each
  const aWeb = tw * webWidth
  const iWeb = webWidth * tw ** 3 / 12
  const steps = [
    `Web length each side of the stiffener centreline = min(17.5 tw/√(fy/250), s/2) = ${fmt(each, 3)} mm (Clause 5.14.2).`,
    `Web strip area = ${fmt(aWeb, 3)} mm². Web strip I about the web centreline = ${fmt(iWeb, 3)} mm⁴.`,
  ]
  if (pos(input.isMm4) && pos(input.asMm2)) {
    const area = input.asMm2 + aWeb
    const inertia = input.isMm4 + iWeb
    steps.push(`Entered stiffener area ${fmt(input.asMm2, 3)} mm² and I ${fmt(input.isMm4, 4)} mm⁴ about the web centreline, excluding the web strip.`)
    return { ok: true, area, inertia, ry: Math.sqrt(inertia / area), steps }
  }
  if ((input.arrangement === "pair" || input.arrangement === "single-plate") && pos(input.tsMm) && pos(input.besMm)) {
    const one = input.tsMm * input.besMm
    const as = input.arrangement === "pair" ? 2 * one : one
    if (pos(input.asMm2) && Math.abs(input.asMm2 - as) / as > 0.01) {
      return { ok: false, missing: "The entered stiffener area does not match ts × bes for the selected arrangement. One of them is wrong." }
    }
    const ys = tw / 2 + input.besMm / 2
    const iOwn = input.tsMm * input.besMm ** 3 / 12
    if (input.arrangement === "pair") {
      const inertia = 2 * (iOwn + one * ys * ys) + iWeb
      const area = as + aWeb
      steps.push(`Pair of flat plates, each ${fmt(input.besMm, 3)} × ${fmt(input.tsMm, 3)} mm. I is about the axis parallel to the web.`)
      return { ok: true, area, inertia, ry: Math.sqrt(inertia / area), steps }
    }
    const area = as + aWeb
    const yBar = (as * ys) / area
    const inertia = iOwn + as * (ys - yBar) ** 2 + iWeb + aWeb * yBar ** 2
    steps.push(`Single flat plate ${fmt(input.besMm, 3)} × ${fmt(input.tsMm, 3)} mm. Centroid is offset from the web centreline.`)
    return { ok: true, area, inertia, ry: Math.sqrt(inertia / area), steps }
  }
  return { ok: false, missing: "Stiffener buckling needs either a flat-plate outstand and thickness, or As and Is about the axis parallel to the web. A single angle is not given an I from area alone." }
}

function stiffeners(input: DesignInput, shear: { vw: number | null; alphaV: number | null; dp: number | null; tw: number | null }): Check[] {
  if (input.role !== "web") {
    return [blankCheck({
      id: "stiffener", group: "STIFFENER", title: "Stiffener design",
      clause: "5.14 / 5.15 / 5.16", equation: "web stiffener clauses",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "Stiffener clauses 5.14 to 5.16 are web clauses. FEM EI is not an AS 4100 stiffener capacity.",
    })]
  }
  if (input.stiffener == null) {
    return [blankCheck({
      id: "stiffener", group: "STIFFENER", title: "Stiffener design",
      clause: "5.14 / 5.15 / 5.16", equation: "area, stiffness and strength",
      status: "not-checked", result: "NOT CHECKED",
      note: "State none, intermediate transverse, load-bearing, or longitudinal. A line in the FEM model does not select the clause.",
    })]
  }
  if (input.stiffener === "none") {
    return [blankCheck({
      id: "stiffener", group: "STIFFENER", title: "Stiffener design",
      clause: "5.15", equation: "no stiffener",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "No web stiffener is identified. Unstiffened shear and thickness checks still apply where selected.",
    })]
  }
  const stiffScope = outsideMaterial(input.fysMpa, input.tsMm) ?? outsideMaterial(input.fyMpa, input.twMm)
  if (stiffScope) return [scopeRow("stiffener", "STIFFENER", "Stiffener design", "1.1.2", stiffScope)]
  const out: Check[] = []
  const { phi, source } = phiOf("stiffener")
  if (pos(input.besMm) && pos(input.tsMm) && pos(input.fysMpa) && !input.outerStiffened) {
    const limit = 15 * input.tsMm / Math.sqrt(input.fysMpa / 250)
    const ok = input.besMm <= limit + 1e-9
    out.push(blankCheck({
      id: "stiffener-outstand", group: "STIFFENER", title: "Stiffener outstand",
      clause: "5.14.3", equation: "bes ≤ 15 ts / √(fys/250)",
      status: ok ? "pass" : "fail",
      result: `bes ${fmt(input.besMm, 3)} mm vs ${fmt(limit, 3)} mm`,
      phi: null, phiSource: "",
      steps: [`Limit = 15 × ${fmt(input.tsMm, 3)} / √(${fmt(input.fysMpa, 3)}/250) = ${fmt(limit, 3)} mm.`],
      note: "Clause 5.15.6 points intermediate stiffeners to this outstand limit.",
    }))
  } else if (input.outerStiffened) {
    out.push(blankCheck({
      id: "stiffener-outstand", group: "STIFFENER", title: "Stiffener outstand",
      clause: "5.14.3", equation: "limit waived when the outer edge is continuously stiffened",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "The outer edge is identified as continuously stiffened, so the flat-outstand limit is not applied.",
    }))
  } else {
    out.push(data({
      id: "stiffener-outstand", group: "STIFFENER", title: "Stiffener outstand",
      clause: "5.14.3", equation: "bes ≤ 15 ts / √(fys/250)",
      missing: "Outstand bes, thickness ts and stiffener yield stress fys are required, unless the outer edge is continuously stiffened.",
    }))
  }

  if (input.stiffener === "longitudinal" || input.longWhere === "compression" || input.longWhere === "neutral" || input.longWhere === "both") {
    if (!pos(input.d2Mm) || !pos(input.twMm)) {
      out.push(data({
        id: "longitudinal", group: "STIFFENER", title: "Longitudinal stiffener stiffness",
        clause: "5.16.2", equation: "Is ≥ 4 d2 tw³ [1 + 4 r (1 + r)], r = As/(d2 tw)",
        missing: "d2 and tw are required. The stiffener is checked only when you say it is required.",
      }))
    } else if (input.longWhere == null || input.longWhere === "none") {
      out.push(blankCheck({
        id: "longitudinal", group: "STIFFENER", title: "Longitudinal stiffener stiffness",
        clause: "5.16.2", equation: "when required",
        status: "not-checked", result: "NOT CHECKED",
        note: "Clause 5.16.2 applies when a longitudinal stiffener is required at 0.2 d2 or at the neutral axis. That choice is not made.",
      }))
    } else if (!pos(input.isLongMm4) || (input.longWhere !== "neutral" && !pos(input.asLongMm2))) {
      out.push(data({
        id: "longitudinal", group: "STIFFENER", title: "Longitudinal stiffener stiffness",
        clause: "5.16.2", equation: "Is about the face of the web",
        missing: "Enter Is about the face of the web. The 0.2 d2 stiffener also needs its area As.",
      }))
    } else {
      const d2 = input.d2Mm
      const tw = input.twMm
      const r = (input.asLongMm2 ?? 0) / (d2 * tw)
      const atCompression = 4 * d2 * tw ** 3 * (1 + 4 * r * (1 + r))
      const atNeutral = d2 * tw ** 3
      const need = input.longWhere === "neutral" ? atNeutral : input.longWhere === "compression" ? atCompression : Math.max(atCompression, atNeutral)
      const ok = input.isLongMm4 + 1e-6 >= need
      out.push(blankCheck({
        id: "longitudinal", group: "STIFFENER", title: "Longitudinal stiffener stiffness",
        clause: "5.16.2", equation: "Is ≥ 4 d2 tw³ [1 + 4 (As/(d2 tw)) (1 + As/(d2 tw))]",
        status: ok ? "pass" : "fail",
        result: `Is ${fmt(input.isLongMm4, 4)} mm⁴ vs ${fmt(need, 4)} mm⁴`,
        steps: [
          `r = As/(d2 tw) = ${fmt(r, 4)}.`,
          `Compression-flange stiffener requirement = ${fmt(atCompression, 4)} mm⁴.`,
          `Neutral-axis stiffener requirement = d2 tw³ = ${fmt(atNeutral, 4)} mm⁴.`,
        ],
        note: "Checked because this stiffener was identified as required. FEM GJ is not Is.",
      }))
    }
  }

  if (input.stiffener === "intermediate" || input.stiffener === "load-bearing") {
    const gamma = gammaOf(input.arrangement)
    if (input.stiffener === "intermediate") {
      if (shear.alphaV == null || shear.vw == null || !pos(shear.dp) || !pos(input.sMm) || gamma == null || input.webGross !== "gross") {
        out.push(data({
          id: "stiffener-area", group: "STIFFENER", title: "Intermediate stiffener area",
          clause: "5.15.3", equation: "As ≥ 0.5 γ Aw (1−αv) [(s/dp)² − (s/dp)²/√(1+(s/dp)²)]",
          missing: "Needs a stiffened-web αv, gross Aw, spacing s, dp, and pair / single-angle / single-plate.",
        }))
      } else {
        const sOver = input.sMm / shear.dp
        const bracket = sOver ** 2 - sOver ** 2 / Math.sqrt(1 + sOver ** 2)
        const aw = shear.dp * (shear.tw ?? input.twMm ?? 0)
        const required = Math.max(0, 0.5 * gamma * aw * (1 - shear.alphaV) * bracket)
        const provided = input.asMm2
        const status = provided == null ? "not-checked" : provided + 1e-9 >= required ? "pass" : "fail"
        out.push(blankCheck({
          id: "stiffener-area", group: "STIFFENER", title: "Intermediate stiffener area",
          clause: "5.15.3", equation: "As ≥ 0.5 γ Aw (1−αv) [(s/dp)² − (s/dp)²/√(1+(s/dp)²)]",
          status, result: provided == null ? `required ≥ ${fmt(required, 3)} mm²` : `${fmt(provided, 3)} mm² vs ${fmt(required, 3)} mm²`,
          steps: [`γ = ${gamma}. αv = ${fmt(shear.alphaV, 4)}. Bracket = ${fmt(bracket, 4)}. Required As = ${fmt(required, 3)} mm².`],
          note: "External loads on the stiffener are not included. Clause 5.15.7 is separate.",
        }))
      }
      if (pos(input.d1Mm) && pos(input.twMm) && pos(input.sMm) && pos(input.isMm4)) {
        const sOverD = input.sMm / input.d1Mm
        const requiredI = sOverD <= Math.SQRT2
          ? 0.75 * input.d1Mm * input.twMm ** 3
          : 1.5 * input.d1Mm * input.twMm ** 3 / sOverD ** 2
        let extra = 0
        const extraOn = input.fnN != null || input.fpN != null || input.mpNmm != null
        if (extraOn) {
          if (input.modulusMpa == null || !(input.modulusMpa > 0)) {
            out.push(data({
              id: "stiffener-stiffness", group: "STIFFENER", title: "Intermediate stiffener stiffness",
              clause: "5.15.7.1", equation: "increase of Is",
              missing: "An external force or moment is entered, so E is required for the Clause 5.15.7.1 increase. Plate E is not taken silently.",
            }))
          } else {
            const fn = input.fnN ?? 0
            const fp = input.fpN ?? 0
            const mp = input.mpNmm ?? 0
            const e = input.eccMm ?? 0
            extra = input.d1Mm ** 4 * (2 * fn + (mp + fp * e) / input.d1Mm) / (phi * input.modulusMpa * input.d1Mm * input.twMm)
          }
        }
        if (!out.some((row) => row.id === "stiffener-stiffness" && row.status === "data-required")) {
          const need = requiredI + Math.max(0, extra)
          const ok = input.isMm4 + 1e-6 >= need
          out.push(blankCheck({
            id: "stiffener-stiffness", group: "STIFFENER", title: "Intermediate stiffener stiffness",
            clause: "5.15.5", equation: "Is ≥ 0.75 d1 tw³, or 1.5 d1 tw³ / (s/d1)²",
            status: ok ? "pass" : "fail",
            result: `Is ${fmt(input.isMm4, 4)} mm⁴ vs ${fmt(need, 4)} mm⁴`,
            steps: [
              `s/d1 = ${fmt(sOverD, 4)}. Base Is = ${fmt(requiredI, 4)} mm⁴.`,
              "The second limit printed in Clause 5.15.5 is Is ≥ 1.5 d1³ tw³ / s² for s/d1 > √2. That is the same as 1.5 d1 tw³ / (s/d1)². Both sides are a second moment of area (length⁴). The first limit is Is ≥ 0.75 d1 tw³ for s/d1 ≤ √2. They meet at s/d1 = √2.",
              extraOn ? `Clause 5.15.7.1 increase = ${fmt(extra, 4)} mm⁴.` : "No external force was entered, so Clause 5.15.7.1 is not added.",
            ],
            note: "Is is about the centreline of the web.",
          }))
        }
      } else {
        out.push(data({
          id: "stiffener-stiffness", group: "STIFFENER", title: "Intermediate stiffener stiffness",
          clause: "5.15.5", equation: "Is ≥ 0.75 d1 tw³ or 1.5 d1 tw³/(s/d1)²",
          missing: "d1, tw, s and Is about the web centreline are required.",
        }))
      }
    }

    if (!pos(input.fyMpa) || !pos(input.twMm) || !pos(input.d1Mm) || input.fysMpa == null) {
      out.push(data({
        id: "stiffener-strength", group: "STIFFENER", title: "Stiffener strength",
        clause: input.stiffener === "load-bearing" ? "5.14" : "5.15.4",
        equation: "Rsb from Clause 6.3.3 with αb = 0.5 and kf = 1",
        missing: "fy, fys, tw and d1 are required. If fys differs from fy, Section 6 has one yield stress and this check stops.",
      }))
    } else if (Math.abs(input.fysMpa - input.fyMpa) > 0.05) {
      out.push(blankCheck({
        id: "stiffener-strength", group: "STIFFENER", title: "Stiffener strength",
        clause: "5.14.2", equation: "Section 6 with one fy",
        status: "data-required", result: "VERIFIED STANDARD DATA REQUIRED",
        note: `Stiffener fys ${fmt(input.fysMpa, 3)} MPa differs from web fy ${fmt(input.fyMpa, 3)} MPa. Clause 5.14.2 points to Section 6, which is written for one yield stress. No hybrid capacity is invented.`,
      }))
    } else {
      const section = stiffenerSection(input, input.fyMpa, input.twMm)
      if (!section.ok) {
        out.push(data({
          id: "stiffener-strength", group: "STIFFENER", title: "Stiffener buckling",
          clause: "5.14.2", equation: "Nc = αc Ns",
          missing: section.missing,
        }))
      } else {
        const leFactor = input.stiffener === "intermediate" ? 1 : input.stiffenerLe === "0.7d1" ? 0.7 : input.stiffenerLe === "d1" ? 1 : null
        if (leFactor == null) {
          out.push(data({
            id: "stiffener-strength", group: "STIFFENER", title: "Load-bearing stiffener buckling",
            clause: "5.14.2", equation: "le = 0.7 d1 or d1",
            missing: "Say whether the flanges restrain rotation in the plane of the stiffener (le = 0.7 d1) or not (le = d1).",
            steps: section.steps,
          }))
        } else {
          const le = leFactor * input.d1Mm
          const column = columnCapacity({
            leOverR: le / section.ry, fyMpa: input.fyMpa, areaMm2: section.area, alphaB: 0.5, kf: 1,
          })
          const steps = [
            ...section.steps,
            `le = ${leFactor === 1 && input.stiffener === "intermediate" ? "d1 (Clause 5.15.4)" : leFactor === 0.7 ? "0.7 d1" : "d1"} = ${fmt(le, 3)} mm.`,
            `ry = ${fmt(section.ry, 3)} mm. λn = ${fmt(column.lambdaN, 3)}. αc = ${fmt(column.alpha, 4)}.`,
            `Rsb = αc × 1.0 × ${fmt(section.area, 3)} × ${fmt(input.fyMpa, 3)} = ${kn(column.nc)}.`,
          ]
          if (input.stiffener === "load-bearing") {
            if (!pos(input.bbfMm)) {
              out.push(data({
                id: "stiffener-strength", group: "STIFFENER", title: "Load-bearing stiffener yield",
                clause: "5.14.1", equation: "Rsy = Rby + As fys",
                missing: "bbf is required so Rby = 1.25 bbf tw fy can be added to As fys.",
                steps,
              }))
            } else if (!pos(input.asMm2)) {
              out.push(data({
                id: "stiffener-strength", group: "STIFFENER", title: "Load-bearing stiffener yield",
                clause: "5.14.1", equation: "Rsy = Rby + As fys",
                missing: "Stiffener area As in contact with the flange is required.",
                steps,
              }))
            } else {
              const rby = 1.25 * input.bbfMm * input.twMm * input.fyMpa
              const rsy = rby + input.asMm2 * input.fysMpa
              const designY = phi * rsy
              const designB = phi * column.nc
              const action = input.rStarN
              const yUse = action == null ? null : utilisation(action, designY)
              const bUse = action == null ? null : utilisation(action, designB)
              const ratio = yUse && bUse ? Math.max(yUse.ratio, bUse.ratio) : null
              out.push(blankCheck({
                id: "stiffener-strength", group: "STIFFENER", title: "Load-bearing stiffener",
                clause: "5.14.1 and 5.14.2", equation: "R* ≤ φ Rsy and R* ≤ φ Rsb",
                status: ratio == null ? "not-checked" : ratio <= 1 ? "pass" : "fail",
                result: ratio == null ? `φRsy = ${kn(designY)}; φRsb = ${kn(designB)}` : `${fmt(ratio, 3)}`,
                nominal: Math.min(rsy, column.nc), nominalUnit: "N", phi, phiSource: source,
                designCapacity: Math.min(designY, designB), action, utilisation: ratio,
                steps: [...steps, `Rby = ${kn(rby)}. Rsy = Rby + As fys = ${kn(rsy)}. φRsy = ${kn(designY)}. φRsb = ${kn(designB)}.`],
                note: "Both yield and buckling are required. The governing utilisation is the larger ratio.",
              }))
            }
          } else if (shear.vw != null && shear.alphaV != null && pos(shear.dp)) {
            const vb = Math.min(shear.vw, shear.alphaV * shear.vw)
            const design = phi * (column.nc + vb)
            const action = input.vStarN
            const used = action == null ? null : utilisation(action, design)
            out.push(blankCheck({
              id: "stiffener-strength", group: "STIFFENER", title: "Intermediate stiffener buckling",
              clause: "5.15.4", equation: "V* ≤ φ (Rsb + Vb) with αd = 1 and αf = 1",
              status: used?.status ?? "not-checked",
              result: action == null ? `φ(Rsb+Vb) = ${kn(design)}` : `${fmt(used!.ratio, 3)}`,
              nominal: column.nc + vb, nominalUnit: "N", phi, phiSource: source, designCapacity: design,
              action, utilisation: used?.ratio ?? null,
              steps: [...steps, `Vb uses αd = 1 and αf = 1, so Vb = ${kn(vb)}. φ(Rsb+Vb) = ${kn(design)}.`],
              note: "This Vb is not the shear capacity used in Clause 5.11, because αd and αf are set to 1.",
            }))
          } else {
            out.push(data({
              id: "stiffener-strength", group: "STIFFENER", title: "Intermediate stiffener buckling",
              clause: "5.15.4", equation: "V* ≤ φ(Rsb+Vb)",
              missing: "Shear yield Vw and stiffened αv are required before Vb can be added to Rsb.",
              steps,
            }))
          }
        }
      }
    }

    if (input.stiffener === "intermediate" && pos(input.twMm) && pos(input.fyMpa) && pos(input.besMm)) {
      const required = 0.0008 * input.twMm ** 2 * input.fyMpa / input.besMm
      const provided = input.weldKnPerMm
      out.push(blankCheck({
        id: "stiffener-weld", group: "STIFFENER", title: "Stiffener-to-web connection",
        clause: "5.15.8", equation: "0.0008 tw² fy / bes",
        status: provided == null ? "not-checked" : provided + 1e-9 >= required ? "pass" : "fail",
        result: provided == null ? `required ${fmt(required, 4)} kN/mm` : `${fmt(provided, 4)} vs ${fmt(required, 4)} kN/mm`,
        steps: [`With tw and bes in mm and fy in MPa, the required design shear is ${fmt(required, 4)} kN/mm.`],
        note: "Compared only with a weld capacity you enter. Nothing is assumed about the weld size.",
      }))
    }
  }

  if (input.endPost) {
    if (shear.alphaV == null || shear.vw == null || !pos(input.d1Mm) || !pos(input.fyMpa) || !pos(input.endGapMm) || input.vStarN == null) {
      out.push(data({
        id: "end-post", group: "STIFFENER", title: "End post",
        clause: "5.15.9", equation: "Aep ≥ d1 [(V*/φ) − αv Vw] / (8 e fy)",
        missing: "End-post area needs d1, fy, the gap e between the end plate and the load-bearing stiffener, V*, αv and Vw.",
      }))
    } else {
      const demand = input.d1Mm * (input.vStarN / phi - shear.alphaV * shear.vw) / (8 * input.endGapMm * input.fyMpa)
      const required = Math.max(0, demand)
      const provided = input.aepMm2
      out.push(blankCheck({
        id: "end-post", group: "STIFFENER", title: "End post area",
        clause: "5.15.9", equation: "Aep ≥ d1 [(V*/φ) − αv Vw] / (8 e fy)",
        status: provided == null ? "not-checked" : provided + 1e-9 >= required ? "pass" : "fail",
        result: provided == null ? `required ≥ ${fmt(required, 3)} mm²` : `${fmt(provided, 3)} mm² vs ${fmt(required, 3)} mm²`,
        phi, phiSource: source,
        steps: [`Uncapped expression = ${fmt(demand, 3)} mm². Required area = ${fmt(required, 3)} mm². The load-bearing stiffener itself is still Clause 5.14.`],
        note: "A negative expression means V*/φ does not exceed αv Vw, so the area inequality does not demand plate area.",
      }))
    }
  }

  if (input.soleTorsion) {
    if (!pos(input.asMm2) || !pos(input.isMm4) || !pos(input.d1Mm) || !pos(input.torsionDepthMm) || !pos(input.torsionTfMm) || !pos(input.rStarN) || !pos(input.fMemberN)) {
      out.push(data({
        id: "torsion-restraint", group: "STIFFENER", title: "Torsional end restraint",
        clause: "5.14.5", equation: "Is ≥ (αt/1000) (d³ tf R*/F*)",
        missing: "Required when these stiffeners are the sole torsional restraint: d1, critical-flange depth d, flange thickness tf, R*, total design load F* between supports, and the pair area As and second moment Is.",
      }))
    } else if (input.stiffenerLe == null) {
      out.push(data({
        id: "torsion-restraint", group: "STIFFENER", title: "Torsional end restraint",
        clause: "5.14.5", equation: "le from Clause 5.14.2",
        missing: "Say whether the flanges restrain rotation in the plane of the stiffener (le = 0.7 d1) or not (le = d1). le is not assumed.",
      }))
    } else {
      const sectionRy = Math.sqrt(input.isMm4 / input.asMm2)
      const le = (input.stiffenerLe === "0.7d1" ? 0.7 : 1) * input.d1Mm
      const slenderness = le / sectionRy
      const alphaT = Math.min(4, Math.max(0, 230 / slenderness - 0.6))
      const required = (alphaT / 1000) * (input.torsionDepthMm ** 3 * input.torsionTfMm * input.rStarN / input.fMemberN)
      out.push(blankCheck({
        id: "torsion-restraint", group: "STIFFENER", title: "Torsional end restraint",
        clause: "5.14.5", equation: "Is ≥ (αt/1000) (d³ tf R*/F*), 0 ≤ αt ≤ 4",
        status: input.isMm4 + 1e-6 >= required ? "pass" : "fail",
        result: `Is ${fmt(input.isMm4, 4)} mm⁴ vs ${fmt(required, 4)} mm⁴`,
        steps: [`le/ry = ${fmt(slenderness, 3)}. αt = 230/(le/ry) − 0.60 = ${fmt(alphaT, 4)}, limited to 0…4. ry is √(Is/As) from the entered pair, not from the web-strip section.`],
        note: "Used only because the stiffeners were identified as the sole torsional restraint of the member.",
      }))
    }
  }
  return out
}

function openings(input: DesignInput): Check {
  if (input.role !== "web") {
    return blankCheck({
      id: "openings", group: "WEB", title: "Openings",
      clause: "5.10.7", equation: "lw/d1 limits",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "Not a web.",
    })
  }
  if (input.openings == null) {
    return blankCheck({
      id: "openings", group: "WEB", title: "Openings",
      clause: "5.10.7", equation: "lw/d1 ≤ 0.10 or 0.33",
      status: "not-checked", result: "NOT CHECKED",
      note: "Say there is no opening, or enter the greatest internal dimension. Castellated and stiffened openings need a rational analysis and are outside this check.",
    })
  }
  if (input.openings === "none") {
    return blankCheck({
      id: "openings", group: "WEB", title: "Openings",
      clause: "5.10.7", equation: "no opening",
      status: "not-applicable", result: "NOT APPLICABLE",
      note: "No web opening is identified.",
    })
  }
  if (!pos(input.lwMm) || !pos(input.d1Mm)) {
    return data({
      id: "openings", group: "WEB", title: "Openings",
      clause: "5.10.7", equation: "lw/d1",
      missing: "Opening dimension lw and clear depth d1 are required. Spacing of adjacent openings is not checked unless you confirm it separately — one opening is checked here.",
    })
  }
  const ratio = input.lwMm / input.d1Mm
  const limit = input.openingStiffened ? 0.33 : 0.1
  return blankCheck({
    id: "openings", group: "WEB", title: "Unstiffened opening proportion",
    clause: "5.10.7", equation: input.openingStiffened ? "lw/d1 ≤ 0.33" : "lw/d1 ≤ 0.10",
    status: ratio <= limit + 1e-12 ? "pass" : "fail",
    result: `lw/d1 = ${fmt(ratio, 3)} vs ${limit}`,
    note: "The 0.33 limit applies when the member is longitudinally stiffened. It is not a capacity for a stiffened opening or a castellated member. Adjacent-opening spacing is not measured.",
  })
}

function appendix(input: DesignInput, vv: number | null): Check {
  if (!input.appendixI) {
    return blankCheck({
      id: "appendix-i", group: "APPENDIX I", title: "Stiffened web combined actions",
      clause: "Appendix I", equation: "I.1 yield and I.2 buckling",
      status: "not-checked", result: "NOT CHECKED", normative: false, kind: "information",
      note: "Appendix I is informative. It is not a normative φRu. Leave it off and it is listed as not run; it does not silently pass.",
    })
  }
  if (!pos(input.dpMm) || !pos(input.twMm) || !pos(input.fyMpa) || !pos(input.sMm) || !pos(input.bbfMm)) {
    return data({
      id: "appendix-i", group: "APPENDIX I", title: "Combined actions",
      clause: "Appendix I", equation: "I.1 and I.2",
      missing: "Informative check needs dp, tw, fy, s and bbf. Actions Mw*, Vw*, Nw* and Rw* are the web-panel actions in Figure I.1, not the elastic eigenvalue.",
      normative: false, kind: "information",
    })
  }
  if (input.mwNmm == null || input.vwN == null || input.nwN == null || input.rwN == null || vv == null) {
    return data({
      id: "appendix-i", group: "APPENDIX I", title: "Combined actions",
      clause: "I.1", equation: "(Rw*/(φ bbf tw))² + (fw*/φ)² + (Vw*/(0.6 φ Aw))² ≤ fy²",
      missing: "Enter the four panel actions. Vv from Clause 5.11 must already be available for I.2.",
      normative: false, kind: "information",
    })
  }
  const aw = input.dpMm * input.twMm
  const zwe = input.twMm * input.dpMm ** 2 / 6
  const fw = input.nwN / aw + 0.77 * input.mwNmm / zwe
  const { phi } = phiOf("shear")
  const termR = input.rwN / (phi * input.bbfMm * input.twMm)
  const termF = fw / phi
  const termV = input.vwN / (0.6 * phi * aw)
  const yieldSide = termR ** 2 + termF ** 2 + termV ** 2
  const fy2 = input.fyMpa ** 2
  const root = input.dpMm / input.twMm * Math.sqrt(input.fyMpa / 250)
  const nwo = Math.min(aw * input.fyMpa, 45 * aw * input.fyMpa / root)
  const beta = 0.1 + 20 / root
  const rsb = beta * input.bbfMm * input.twMm * input.fyMpa
  const b = input.bbfMm / input.sMm
  const alphaW = (3.4 + 2.2 * input.dpMm / input.sMm) * (0.4 + 0.5 * b)
  const de = 1.9 * Math.sqrt(input.bbfMm * input.dpMm) / alphaW
  const mwNominal = input.fyMpa * zwe
  const buckle = (input.rwN / (phi * rsb)) ** 2 + (input.nwN / (phi * nwo)) ** 2 + (input.vwN / (phi * vv)) ** 2 + (input.mwNmm / (phi * mwNominal)) ** 2
  const yieldOk = yieldSide <= fy2 + 1e-6
  const bucklePass = buckle <= 1 + 1e-9
  return blankCheck({
    id: "appendix-i", group: "APPENDIX I", title: "Informative combined check",
    clause: "I.1 and I.2", equation: "yield criterion and buckling criterion",
    status: yieldOk && bucklePass ? "pass" : "fail",
    normative: false, kind: "information",
    result: `yield ${fmt(yieldSide / fy2, 3)} of fy²; buckling ${fmt(buckle, 3)}`,
    steps: [
      `Zwe = tw dp²/6 = ${fmt(zwe, 3)} mm³. fw* = Nw*/Aw + 0.77 Mw*/Zwe = ${fmt(fw, 3)} MPa.`,
      `Yield left side = ${fmt(yieldSide, 4)}; fy² = ${fmt(fy2, 4)}.`,
      `Nwo = min(Aw fy, 45 Aw fy / ((dp/tw)√(fy/250))) = ${kn(nwo)}.`,
      `βw = 0.10 + 20/((dp/tw)√(fy/250)) = ${fmt(beta, 4)}. Rsb = βw bbf tw fy = ${kn(rsb)}.`,
      `αw = ${fmt(alphaW, 4)} and de = ${fmt(de, 3)} mm are defined on the following page. They are not substituted, because I.2 writes Rsb = βw bbf tw fy and does not place de inside that inequality.`,
      `Mw for I.2 is taken as fy Zwe. If the web element is slender in bending, Clause 5.2.5 does not give the gradient Ze, so this Mw is only the elastic value stated with Zwe.`,
      `Buckling sum = ${fmt(buckle, 4)}.`,
    ],
    note: "Informative only. A pass here is not an AS 4100 design capacity and is excluded from the governing utilisation.",
  })
}

export function evaluateAs4100(partial: Partial<DesignInput>): Report {
  const input = { ...designDefaults(), ...partial }
  const rejected = invalidInput(input)
  if (rejected) {
    return {
      meta: AS4100_META,
      checks: [blankCheck({
        id: "input", group: "INPUT", title: "Design input",
        clause: "1.1.2", equation: "finite positive geometry and material",
        status: "invalid", result: "INVALID INPUT",
        note: rejected,
      })],
      diagram: { edges: input.edgesSupported, stress: input.stress ?? "not selected", clearMm: input.clearWidthMm, effectiveMm: null, thicknessMm: input.thicknessMm },
      limitations: [rejected, "No capacity was calculated from this input."],
      governing: "No utilisation — the input is invalid",
      governingUtil: null,
      overall: "not-complete",
      headline: "NOT A COMPLETE PASS — invalid input does not receive a design result",
    }
  }
  const slend = slenderness(input)
  const checks: Check[] = [...slend.checks, ...axial(input, slend.be), webThickness(input)]
  const shear = shearCheck(input)
  checks.push(shear.check)
  checks.push(interaction(input, shear.check.designCapacity, shear.check.nominal))
  checks.push(...bearing(input))
  checks.push(...stiffeners(input, shear))
  checks.push(openings(input))
  checks.push(appendix(input, shear.check.nominal))
  checks.push(blankCheck({
    id: "member-nc", group: "OUTSIDE SCOPE", title: "Member buckling Nc",
    clause: "6.3", equation: "Nc = αc Ns",
    status: "out-of-scope", result: "OUTSIDE IMPLEMENTED SCOPE", kind: "information",
    normative: false,
    note: "A plate panel does not have member length, effective-length factor or section constant αb. Clause 6.3.3 is used only where 5.13.4 or 5.14.2 call it up for the web strip or stiffener.",
  }))

  const ranked = checks.filter((row) =>
    row.normative
    && row.kind === "strength"
    && (row.status === "pass" || row.status === "fail")
    && row.utilisation != null
    && Number.isFinite(row.utilisation)
  )
  ranked.sort((a, b) => (b.utilisation ?? 0) - (a.utilisation ?? 0))
  const top = ranked[0] ?? null
  const blocked = checks.filter(blocks)
  const service = checks.filter((row) => row.kind === "service" && row.status === "fail")
  const overall = blocked.length === 0 && checks.some((row) => row.normative && row.status === "pass") ? "pass" : "not-complete"
  const limitations = [
    "AS 4100 DESIGN SUBSET — VERIFIED WITH LIMITATIONS. This is not complete AS 4100 design verified.",
    "Elastic buckling stress, τcr and λFEM are not design resistances. IQ-PLB-E1.0 is unchanged by this adapter.",
    "φ is 0.90 from Table 3.4 for the clause named on each row. No γM, EN 1993-1-5 or AS 5224 factor is used.",
    "Outside this plate check: general member Nc (Clause 6.3 as a member capacity), lateral-torsional buckling Mb (Clause 5.6), Sections 8.3 and 8.4, RHS bearing αp and Clause 5.13.5, castellated or stiffened openings, hybrid stiffeners fys ≠ fy, and slender bending-gradient Ze where Clause 5.2.5 gives no expression.",
    "Ms, where required by Clause 5.12.3, is an external verified input. Its calculation is outside IQ-CAL-PLB.",
    "Appendix I is informative. It is excluded from the governing utilisation, including when it is left off.",
    "Table 5.11.5.2 is not stored. αv αd follows Clause 5.11.5.2. Two printed cells, (100, s/dp = 1.25) and (110, s/dp = 1.0), are transposed relative to that equation (0.989 and 0.998). The equation is used.",
    ...service.map((row) => `SERVICE — ${row.title}: ${row.result}. ${row.note}`),
    ...blocked.map((row) => `${row.group} — ${row.title}: ${row.status === "data-required" ? "VERIFIED STANDARD DATA REQUIRED" : row.result}. ${row.note}`),
  ]
  const headline = overall === "pass"
    ? service.length
      ? "PASS FOR ALL APPLICABLE IMPLEMENTED CHECKS — SERVICE DEFORMATION WARNING — NOT COMPLETE AS 4100 DESIGN VERIFIED"
      : "PASS FOR ALL APPLICABLE IMPLEMENTED CHECKS — NOT COMPLETE AS 4100 DESIGN VERIFIED"
    : "NOT A COMPLETE PASS — omitted, failed or out-of-scope checks are listed and are not implied to have passed"
  return {
    meta: AS4100_META,
    checks,
    diagram: {
      edges: input.edgesSupported,
      stress: input.stress ?? "not selected",
      clearMm: input.clearWidthMm,
      effectiveMm: slend.be,
      thicknessMm: input.thicknessMm,
    },
    limitations,
    governing: top ? `${top.title} (${top.clause})` : "No utilisation until an action and a design capacity both exist",
    governingUtil: top?.utilisation ?? null,
    overall,
    headline,
  }
}
