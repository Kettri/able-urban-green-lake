IQ-CAL-PLB source archive for third-party review.

Included: application source (src/), public assets, package manifest, Vite config, scripts, and the plate / AS 4100 design UI and calculation modules.

Not included:
- node_modules (reinstall with npm install)
- build output
- AS 4100-2020.pdf — a licensed standard. It is not in this archive.

The plate tool is the /plate route. AS 4100 checks are on DESIGN, or CODE then AS 4100.
Freeze IDs: elastic engine IQ-PLB-E1.0, design subset IQ-PLB-AS4100-D1.0.
This subset is not a complete AS 4100 member design.
